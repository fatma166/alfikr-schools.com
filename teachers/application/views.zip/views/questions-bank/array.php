
Array
(
	[5] => Array
	(
		[0] => Array
		(
			[id] => 5
                    [title] => ما هي عاصمه مصر33
[group_id] => 2
                    [group_name] => المجموعة الأولى
[parent_id] => 0
                    [answers] => Array
(
	[] =>
                        )

[is_correct] => Array
(
	[] =>
                        )

                )

        )

    [2] => Array
(
	[0] => Array
	(
		[id] => 4
                    [title] => كم مدينه تابعه
[group_id] => 2
                    [group_name] => المجموعة الأولى
[parent_id] => 2
                    [answers] => Array
(
	[7] => اجابه متعدد1
[8] => اجابه متعدد11
                        )

                    [is_correct] => Array
(
	[7] => 1
                            [8] => 0
                        )

                )

            [1] => Array
(
	[id] => 3
                    [title] => اين تقع
[group_id] => 2
                    [group_name] => المجموعة الأولى
[parent_id] => 2
                    [answers] => Array
(
	[9] => مم1
	[10] => مم3
                        )

                    [is_correct] => Array
(
	[9] => 0
                            [10] => 1
                        )

                )

            [2] => Array
(
	[id] => 2
                    [title] => ما هي عاصمه مصرمتعدد
[group_id] => 2
                    [group_name] => المجموعة الأولى
[parent_id] => 0
                    [answers] => Array
(
	[] =>
                        )

[is_correct] => Array
(
	[] =>
                        )

                )

        )

    [1] => Array
(
	[0] => Array
	(
		[id] => 1
                    [title] => ما هي عاصمه مصر
[group_id] => 2
                    [group_name] => المجموعة الأولى
[parent_id] => 0
                    [answers] => Array
(
	[5] => اجابه1
	[6] => اجابه 2
                        )

                    [is_correct] => Array
(
	[5] => 1
                            [6] => 0
                        )

                )

        )

)
