<!DOCTYPE html>
<html lang="ar">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo base_url(); ?>../images/favicon.ico">

    <title>منصة الفكر العلمي</title>
    	  
	<!-- Style-->  
	<link rel="stylesheet" href="<?php echo base_url(); ?>../superadmin/assets/sass/main.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>../superadmin/assets/css/bootstrap.rtl.min.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>../superadmin/assets/css/datatable.css" />
    <title>مدارس الفكر العلمي - لوحة الوزارة</title>
    <link rel="icon" href="<?php echo base_url(); ?>../assets/images/logo.png" type="image/x-icon" />
  </head>
  <body>
    <div
      class="dashboard__layout d-flex justify-content-start align-items-start flex-row"
    >
	
	
	
	<?php $this->load->view('template/right_menu'); ?>
	<?php $this->load->view('template/header'); ?>
	
	
	