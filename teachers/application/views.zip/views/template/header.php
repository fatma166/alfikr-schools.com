<div
        class="wrraper_page d-flex justify-content-start align-items-start flex-column w-100"
      >
        <div
          class="header__dahsboard d-flex justify-content-between flex-row align-items-center w-100 flex-wrap gap-2"
        >
          <div
            class="right__btns d-flex justify-content-start flex-row align-items-center"
          >
            <a href="">
              <img
                src="<?php echo base_url(); ?>../assets/images/message.svg"
                alt="chat"
                width="23"
                height="23"
                loading="lazy"
              />
            </a>
            <a href="">
              <img
                src="<?php echo base_url(); ?>../assets/images/mail.svg"
                alt="chat"
                width="23"
                height="23"
                loading="lazy"
              />
            </a>
            <a href="">
              <img
                src="<?php echo base_url(); ?>../assets/images/task.svg"
                alt="chat"
                width="23"
                height="23"
                loading="lazy"
              />
            </a>
          </div>
          <div
            class="left__btns d-flex justify-content-start flex-row align-items-center"
          >
            <a href="">
              <img
                src="<?php echo base_url(); ?>../assets/images/mirroring-screen.svg"
                alt="chat"
                width="40"
                height="40"
                loading="lazy"
              />
            </a>
            <div class="input-group">
              <span class="input-group-text" id="basic-addon1">
                <img src="<?php echo base_url(); ?>../assets/images/search-md.svg" alt="search" width="20" height="20" loading="lazy"/>
              </span>
              <input
                type="text"
                class="form-control"
                placeholder="بحث"
                aria-label="Username"
                aria-describedby="basic-addon1"
              />
            </div>
            <a href="">
              <img
                src="<?php echo base_url(); ?>../assets/images/notification.svg"
                alt="chat"
                width="40"
                height="40"
                loading="lazy"
              />
            </a>
            <a href="">
              <img
                src="<?php echo base_url(); ?>../assets/images/profile.svg"
                alt="chat"
                width="40"
                height="40"
                loading="lazy"
              />
            </a>
            <a href="">
              <img
                src="<?php echo base_url(); ?>../assets/images/setting.svg"
                alt="chat"
                width="40"
                height="40"
                loading="lazy"
              />
            </a>
          </div>
        </div>
