
		 
		 
		 
		 
		 
		 <aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar position-relative">	
	  	<div class="multinav">
		  <div class="multinav-scroll" style="height: 100%;">	
			  <!-- sidebar menu-->
			  <ul class="sidebar-menu" data-widget="tree">	
				
				
				
				<?php foreach($right_menu as $m){ ?>
                  <li class="treeview">
				  <a><i class="fa <?php echo $m->icon; ?>"></i> 
				  <span><?php echo $m->ar_title; ?> </span>
				  <span class="pull-right-container">
					  <i class="fa fa-angle-right pull-right"></i>
					</span>
				  
				  </a>
                    <ul class="treeview-menu">
                      <?php foreach($m->children as $c){ ?>
                      <?php if($c->id != 32){ ?>
					  <li><a href="<?php echo base_url(); ?><?php echo $c->link; ?>"><?php echo $c->ar_title; ?></a></li>
					  <?php } ?>
                      <?php } ?>
                    </ul>
                  </li>
				<?php } ?>
				
				
				 		
				
				
					 	     
			  </ul>
		  </div>
		</div>
    </section>
	<div class="sidebar-footer">
		<a href="javascript:void(0)" class="link" data-toggle="tooltip" title="" data-original-title="Settings" aria-describedby="tooltip92529"><span class="icon-Settings-2"></span></a>
		<a href="mailbox.html" class="link" data-toggle="tooltip" title="" data-original-title="Email"><span class="icon-Mail"></span></a>
		<a href="<?php echo base_url(); ?>login/logout" class="link" data-toggle="tooltip" title="" data-original-title="تسجيل خروج"><span class="icon-Lock-overturning"><span class="path1"></span><span class="path2"></span></span></a>
	</div>
  </aside>