<script>
 $(document).ready(function() {
    $('select').select2({ width: '100%' });
});
</script>

<style>
	select{
		width: 200px;
	}
</style>


<!-- Vendor JS -->
	
	<script src="<?php echo base_url(); ?>js/pages/chat-popup.js"></script>
    <script src="<?php echo base_url(); ?>../assets/icons/feather-icons/feather.min.js"></script>	

	<script src="<?php echo base_url(); ?>../assets/vendor_components/apexcharts-bundle/dist/apexcharts.js"></script>
	<script src="<?php echo base_url(); ?>../assets/vendor_components/moment/min/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>../assets/vendor_components/fullcalendar/fullcalendar.js"></script>
	
	<script src="<?php echo base_url(); ?>../assets/icons/feather-icons/feather.min.js"></script>	
	<script src="<?php echo base_url(); ?>../assets/vendor_components/datatable/datatables.min.js"></script>
	<script src="<?php echo base_url(); ?>../assets/vendor_components/chart.js-master/Chart.min.js"></script>
	<script src="<?php echo base_url(); ?>../assets/vendor_components/apexcharts-bundle/dist/apexcharts.js"></script>
	<!-- EduAdmin App -->
	<script src="<?php echo base_url(); ?>js/template.js"></script>
	<script src="<?php echo base_url(); ?>js/pages/dashboard.js"></script>
	<script src="<?php echo base_url(); ?>js/pages/calendar.js"></script>
	<script src="<?php echo base_url(); ?>select2/dist/js/select2.full.min.js"></script>
	
</body>
</html>
