<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo base_url(); ?>../images/favicon.ico">

    <title>منصة الفكر العلمي</title>
    
	<!-- Vendors Style-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/vendors_css.css">
	  
	<!-- Style-->  
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/style.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/skin_color.css">
	<script src="<?php echo base_url(); ?>js/vendors.min.js"></script>
	<link href="<?php echo base_url(); ?>select2/dist/css/select2.min.css" rel="stylesheet">
     
  </head>