<?php $this->load->view('template/body'); ?>
<?php if($this->input->get('msg') == "email_exist"){ ?>
<script>
   alert('عذرا .. البريد الالكتروني موجود مسبقاً') ;
</script>
<?php } ?>


<script src="<?php echo base_url(); ?>js/jspdf.js"></script>
		<script src="<?php echo base_url(); ?>js/FileSaver.js"></script>
		<script src="<?php echo base_url(); ?>js/jspdf.plugin.table.js"></script>
		<script src="<?php echo base_url(); ?>js/amiri.js"></script>
			
			<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">الطلاب </h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">القسم الإداري</li>
								<li class="breadcrumb-item active" aria-current="page">الطلاب / إضافة طالب جديد</li>
							</ol>
						</nav>
					</div>
				</div>
				
			</div>
		</div>
			
<section class="content">
			<div class="row">
				<div class="col-12">
					<div class="box">
						
						<div class="box-body">

<form method="post" action="<?php echo base_url(); ?>master/new_student_done">

	<table class="table">
		<tr>
			<td width="200">الاسم الأول</td>
			<td><input type="text" class="form-control" name="first_name" style="width: 300px;" /></td>
		</tr>
		<tr>
			<td>الاسم الثاني</td>
			<td><input type="text" class="form-control" name="last_name"  style="width: 300px;" /></td>
		</tr>
		<tr>
			<td>الموبايل</td>
			<td><input type="text" class="form-control" name="mobile"  style="width: 300px;" /></td>
		</tr>
		<tr>
			<td>البريد الالكتروني</td>
			<td><input type="text" class="form-control" name="email"  style="width: 300px;" /></td>
		</tr>
		<tr>
			<td>كلمة السر</td>
			<td><input type="text" class="form-control" name="password"  style="width: 300px;" /></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" class="btn btn-success" value="إضافة" />
			
			<a href="<?php echo base_url(); ?>master/students" class="btn btn-danger">إلغاء</a>
			</td>
		</tr>
	
	</table>

</div>
						<!-- /.box-body -->
						
						<!-- /.box-footer-->
					</div>
				</div>
			</div>
		</section>
 
 <?php $this->load->view('template/footer'); ?>