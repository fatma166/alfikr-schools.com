<?php $this->load->view('template/body'); ?>

<script>
	
	
	function fetch_subjects_by_course_type(id){
		   //console.log(categories_array);
           $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>master/fetch_subjects_by_course_type",
                data: {'id': id}

            }).done(function (msg) {
                    document.getElementById("subjects").innerHTML = msg;
            });
		}
</script>


     <form method="post" action="<?php echo base_url(); ?>master/new_book"  enctype="multipart/form-data">
<table class='table table-striped '>
	<tr>
		<td style="width: 200px;">اسم الكتاب</td>
		<td ><input type="text" name="name" class="form-control" value="<?php echo $book->name; ?>" required  ></td>
	</tr>
	
	<tr>
		<td>المرحلة الدراسية</td>
		<td>
			<select name="course_type_id" class="form-control" onchange="fetch_subjects_by_course_type(this.value)">
				
				<?php foreach($courses_types as $c){ ?>
					<option value="<?php echo $c->id; ?>" <?php if($c->id == $book->course_type_id){ ?>selected<?php } ?>>
					<?php 
                        
                        echo $c->ar_name;
                      ?>    
					    
					    
					</option>
				<?php } ?>
			</select>

		</td>
	</tr>
	<tr>
		<td>المادة</td>
		<td>
			<select name="main_subject_id" id="subjects" class="form-control">
				<?php foreach($main_subjects as $s){ ?>
				<option value="<?php echo $s->id; ?>" <?php if($s->id == $book->main_subject_id){ ?>selected<?php } ?>><?php echo $s->name; ?></option>
				
				<?php } ?>
				
			</select>

		</td>
	</tr>
        <tr>
            <td>الكتاب</td>
            <td>
			<a href="<?php echo base_url(); ?>../<?php echo $book->link; ?>" target="_blank" >عرض</a>
			<input type="file" class="form-control" name="link" required /></td>
		</tr>
		<tr>
            <td>الصورة</td>
            <td>
			<img src="<?php echo base_url(); ?>../<?php echo $book->image; ?>" width="200" />
			
			<input type="file" class="form-control" name="img" required /></td>
        </tr>
	   
	    
</table>
				
			</form>
      

		
		
		 <?php $this->load->view('template/footer'); ?>