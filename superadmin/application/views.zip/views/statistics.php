<?php $this->load->view('template/body'); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>


<?php $this->load->view('statistics/countries_visitors'); ?>
<?php $this->load->view('statistics/courses_views'); ?>












 
 <?php $this->load->view('template/footer'); ?>