<?php $this->load->view('template/body'); ?>

<script>
    function change_exam_status(id, value){
		   //console.log(categories_array);
           $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>master/change_exam_status",
                data: {'id': id, 'value': value}

            }).done(function (msg) {
                   
            });
    }
</script>

<div class="content-header">
			<div class="d-flex align-items-center">
				<div class="mr-auto">
					<h3 class="page-title">الامتحانات </h3>
					<div class="d-inline-block align-items-center">
						<nav>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>"><i class="mdi mdi-home-outline"></i></a></li>
								<li class="breadcrumb-item" aria-current="page">القسم الإداري</li>
								<li class="breadcrumb-item active" aria-current="page">الامتحانات</li>
							</ol>
						</nav>
					</div>
				</div>
				
			</div>
		</div>

<link rel="stylesheet" href="https://osus.academy/admin/css/jquery-ui.css">
	<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	
	<script>
	
	$(document).ready(function() {
		$('#sandbox-container1').datepicker({
				dateFormat: 'yy-mm-dd'
		});
		
		$('#sandbox-container2').datepicker({
				dateFormat: 'yy-mm-dd'
		});
	
	});
</script>	


<div class="modal center-modal fade" id="modal-center" tabindex="-1">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title">إضافة امتحان جديد</h5>
			<button type="button" class="close" data-dismiss="modal">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <div class="modal-body">
			 <form method="post" action="<?php echo base_url(); ?>master/add_new_exam" enctype="multipart/form-data">
        <table class="table">
            <tR>
                <td>عنوان الامتحان</td>
                <td>
                    <input type="text" name="title"  class="form-control" />
                </td>
            </tR>
			<tR>
                <td>مدة الامتحان بالدقيقة</td>
                <td>
                    <input type="text" name="minutes"  class="form-control" />
                </td>
            </tR>
			<tR>
                <td>نوع الامتحان</td>
                <td>
					<select name="type">
						<option value="اختبار">اختبار</option>
						<option value="واجب">واجب</option>
					</select>
                </td>
            </tR>
			<tR>
                <td>تاريخ البداية</td>
                <td>
                    <input type="text" name="start_date" id="sandbox-container1" autocomplete="off" class="form-control" />
                </td>
            </tR>
			<tR>
                <td>تاريخ النهاية</td>
                <td>
                    <input type="text" name="end_date" id="sandbox-container2"  autocomplete="off" class="form-control" />
                </td>
            </tR>
			
            <tR>
                <td>تفاصيل</td>
                <td>
                    <textarea name="details" class="form-control"></textarea>
                </td>
            </tR>
			
			<tr>
				<td>الشعبة</td>
				<td>
					<select name="course_id" class="form-control"  >
						<?php foreach($courses as $c){ ?>
							<option value="<?php echo $c->id; ?>"><?php echo $c->name; ?></option>
						
						<?php } ?>
					</select>
				</td>
			</tr>
			
					
					
			
            
        </table>
        
			
		  </div>
		  <div class="modal-footer modal-footer-uniform">
		  <button type="submit" class="btn btn-primary ">إضافة</button>
			<button type="button" class="btn btn-secondary float-right" data-dismiss="modal">إلغاء</button>
			
		  </div>
		</div>
		</form>
	  </div>
	</div>




        




<section class="content">
			<div class="row">
				<div class="col-12">
					<div class="box">
						<div class="box-header with-border">
						  <h4 class="box-title">جميع الامتحانات</h4>
						  <button style="float: left;" type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-center">
							امتحان جديد
						  </button>
						</div>
						<div class="box-body">
						<div class="table-responsive">
							<table class='table'>
			<tr>
				<th style="text-align: right"><?php echo $words["id"]; ?></th>
				<th style="text-align: right">عنوان الامتحان</th>
				<th style="text-align: right">المحتويات</th>
				
					<th style="text-align: right">علامات الطلاب</th>
					<th style="text-align: right">الشعبة</th>
					<th style="text-align: right">المدة</th>
					<th style="text-align: right">النوع</th>
					<th style="text-align: right">تاريخ البداية</th>
					<th style="text-align: right">تاريخ النهاية</th>
				<th style="text-align: right">تعطيل/تفعيل</th>
				<th style="text-align: right">حذف</th>
				
				
				
			

			</tr>
	<?php 
		foreach($exams as $b){
	?>
			<tr>
				<td><?php echo $b->id; ?></td>
				<td><?php echo $b->title; ?></td>
				<td><a href="<?php echo base_url(); ?>master/exams_contents/<?php echo $b->id; ?>">المحتويات</a></td>
			
				<td>
				    <a href="<?php echo base_url(); ?>master/exams_students_results/<?php echo $b->id; ?>">علامات الطلاب</a>
				</td>
				<td>
					<?php echo $b->course_name; ?>
				</td>
				
				<td>
					<?php echo $b->minutes; ?> دقيقة
				</td>
				
				<td>
					<?php echo $b->type; ?>
				</td>
				
				<td>
					<?php echo $b->start_date; ?>
				</td>
				
				<td>
					<?php echo $b->end_date; ?>
				</td>
			
			    <td>
			<input type="checkbox" <?php if($b->active == 1){ ?>checked<?php } ?> value="<?php echo $b->id; ?>"  class="js-switch" onchange="change_exam_status(<?php echo $b->id; ?>,<?php if($b->active == 1){ ?>0<?php }else{ ?>1<?php } ?>)"  /> 
		</td>
			    <td><a href="<?php echo base_url(); ?>master/delete/exams/<?php echo $b->id; ?>">حذف</a></td>
			</tr>
	
	<?php
		}
	?>
</table>
</div>

						</div>
						
					</div>
				</div>
			</div>
		</section>

          
 
 
 <?php $this->load->view('template/footer'); ?>