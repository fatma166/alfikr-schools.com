<?php $this->load->view('template/body'); ?>




    
      <form method="post" action="<?php echo base_url(); ?>master/edit_main_subject_done"  enctype="multipart/form-data">
     
         
          <h4 class="modal-title">تعديل المادة الدراسية </h4>
       
        
          <table class="table">
		  	<tr>
				<td>الاسم العربي</td>
				<td><input type="text" name="name" class="form-control" value=" <?php echo $subject->name; ?>" /></td>
			</tr>
			
			
			
			<tr>
				<td>المرحلة الدراسية</td>
				<td>
					<select name="course_type" class="form-control">
						<option value="0">لا يوجد أب</option>
					<?php 
					foreach($courses_types as $c){
						if($c->id == $subject->course_type){
					?>
							<option value='<?php echo $c->id; ?>' selected><?php echo $c->ar_name; ?></option>
					<?php 
						}
						else{
				    ?>
							<option value='<?php echo $c->id; ?>'><?php echo $c->ar_name; ?></option>
					<?php
						}
						
					}	
				    ?>
	                </td>
	            </tr>
	            <tr>
            		<td>الصورة</td>
            		<td>
            			
            			<img src="<?php echo base_url(); ?>../<?php echo $subject->image; ?>" width="200" />
            			<input type="file" name="img" />
            				
            			
            		
            		</td>
            		
            	</tr>
			</table>
     
          <input type="submit" class="btn btn-success"  value="حفظ وإغلاق"></button>
       
	  <input type="hidden" name="main_subject_id" value="<?php echo $subject->id; ?>" />
	  </form>
      

		
		
		 <?php $this->load->view('template/footer'); ?>