<?php $this->load->view('template/body'); ?>


<div class="row" style="padding-top: 40px;">
    <div class="col-12 col-lg-4  col-sm-12 col-md-12">
        <div class="" style="background: #fff;
    margin-bottom: 25px;
    border-radius: 6px;
    padding: 20px;
    border: 1px solid #E8EBED;
    height: 100px;">
            <div style="float:left">
               <h5 style="color: #212B36;
    font-weight: 700;
    font-size: 18px;
    margin-bottom: 5px;">عدد الدروس المرفعة</h5>
               <h6 style="    font-weight: 400;
    font-size: 14px;
    color: #212B36;">
               <?php echo $nof_all_schools[0]->nof_all_schools; ?>
               </h6>
            </div>
            <div style="float: right;   ">
                <i class="fa fa-play" style="display: inline-block;
  border-radius: 50%;
  box-shadow: 0 0 2px #FF9F43;
  padding: 0.5em 0.6em; font-size: 30px; color: #FF9F43;"></i>
            </div>
            
        </div>
    </div>
    <div class="col-12 col-lg-4  col-sm-12 col-md-12">
        <div class="" style="background: #fff;
    margin-bottom: 25px;
    border-radius: 6px;
    padding: 20px;
    border: 1px solid #E8EBED;
    height: 100px;">
            <div style="float:left">
               <h5 style="color: #212B36;
    font-weight: 700;
    font-size: 18px;
    margin-bottom: 5px;">عدد مرات تنزيل الدروس</h5>
               <h6 style="    font-weight: 400;
    font-size: 14px;
    color: #212B36;">
               <?php echo $nof_all_schools[0]->nof_all_schools; ?>
               </h6>
            </div>
            <div style="float: right;   ">
                <i class="fa fa-download" style="display: inline-block;
  border-radius: 50%;
  box-shadow: 0 0 2px #00CFE8;
  padding: 0.5em 0.6em; font-size: 30px; color: #00CFE8;"></i>
            </div>
            
        </div>
    </div>
    <div class="col-12 col-lg-4  col-sm-12 col-md-12">
        <div class="" style="background: #fff;
    margin-bottom: 25px;
    border-radius: 6px;
    padding: 20px;
    border: 1px solid #E8EBED;
    height: 100px;">
            <div style="float:left">
               <h5 style="color: #212B36;
    font-weight: 700;
    font-size: 18px;
    margin-bottom: 5px;">الإيرادات المالية</h5>
               <h6 style="    font-weight: 400;
    font-size: 14px;
    color: #212B36;">
               <?php echo $nof_all_schools[0]->nof_all_schools; ?>
               </h6>
            </div>
            <div style="float: right;   ">
                <i class="fa fa-usd" style="display: inline-block;
  border-radius: 50%;
  box-shadow: 0 0 2px #1B2850;
  padding: 0.5em 0.6em; font-size: 30px; color: #1B2850;"></i>
            </div>
            
        </div>
    </div>
	
	<?php /*
    <div class="col-3 col-lg-3  col-sm-12 col-md-12">
        <div class="" style="background: #fff;
    margin-bottom: 25px;
    border-radius: 6px;
    padding: 20px;
    border: 1px solid #E8EBED;
    height: 100px;">
            <div style="float:left">
               <h5 style="color: #212B36;
    font-weight: 700;
    font-size: 18px;
    margin-bottom: 5px;">الصادرات المالية</h5>
               <h6 style="    font-weight: 400;
    font-size: 14px;
    color: #212B36;">
               <?php echo $nof_all_schools[0]->nof_all_schools; ?>
               </h6>
            </div>
            <div style="float: right;   ">
                <i class="fa fa-bar-chart" style="display: inline-block;
  border-radius: 50%;
  box-shadow: 0 0 2px #28C76F;
  padding: 0.5em 0.6em; font-size: 30px; color: #28C76F;"></i>
            </div>
            
        </div>
    </div> */ ?>
</div>
<div class="row">
    <div class="col-12 col-lg-3  col-sm-12 col-md-12">
        <div class="" style="background: #FF9F43;
        color: #fff;
        min-height: 98px;
        width: 100%;
        border-radius: 6px;
        margin: 0 0 25px;
        padding: 20px;">
            <div style="float:right">
               <h4>عدد المدارس</h4>
               <h3>
               <?php echo $nof_all_schools[0]->nof_all_schools; ?>
               </h3>
            </div>
            <div style="float: left">
                <i class="fa fa-building" style="color:#fff; font-size: 50px;"></i>
            </div>
            
        </div>
    </div>
    <div class="col-12 col-lg-3   col-sm-12 col-md-12">
        <div class="" style="background: #00CFE8;
        color: #fff;
        min-height: 98px;
        width: 100%;
        border-radius: 6px;
        margin: 0 0 25px;
        padding: 20px;">
            <div style="float:right">
               <h4>عدد الطلاب</h4>
               <h3>
               <?php echo $nof_all_students[0]->nof_all_students; ?>
               </h3>
            </div>
            <div style="float: left">
                <i class="fa fa-user" style="color:#fff; font-size: 50px;"></i>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-3  col-sm-12 col-md-12">
        <div class="" style="background: #1B2850;
        color: #fff;
        min-height: 98px;
        width: 100%;
        border-radius: 6px;
        margin: 0 0 25px;
        padding: 20px;">
            <div style="float:right">
               <h4>عدد المدرسين</h4>
               <h3>
                    <?php echo $nof_all_teachers[0]->nof_all_teachers; ?>
                   </h3>
            </div>
            <div style="float: left">
                <i class="fa fa-user" style="color:#fff; font-size: 50px;"></i>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-3   col-sm-12 col-md-12 ">
        <div class="" style="background: #28C76F;
        color: #fff;
        min-height: 98px;
        width: 100%;
        border-radius: 6px;
        margin: 0 0 25px;
        padding: 20px;">
            <div style="float:right">
               <h4>عدد الشعب الدراسية</h4>
               <h3>
               <?php echo $nof_all_coruses[0]->nof_all_coruses; ?>
               
               </h3>
            </div>
            <div style="float: left">
                <i class="fa fa-users" style="color:#fff; font-size: 50px;"></i>
            </div>
        </div>
    </div>
</div>


<div class="row">
				<div class="col-xl-4 col-12">
					<div class="box">
						<div class="box-body">
							
							<div>
								<canvas id="doughnut-chart1" height="200"></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-12">
					<div class="box">
						<div class="box-body">
							
							<div>
								<canvas id="doughnut-chart2" height="200"></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-12">
					<div class="box">
						<div class="box-body">
							
							<div>
								<canvas id="doughnut-chart3" height="200"></canvas>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-12">
							<div class="box">
								<div class="box-header">
									<h4 class="box-title">آخر النشاطات</h4>
								</div>
								<div class="box-body">
									<div class="act-div">
										<div class="bg-gray-100 p-15 rounded10 mb-20">
											<div>
												<span class="badge badge-sm badge-dot badge-warning mr-5"></span>
												مدرسة الفكر
											</div>
											<h4 class="my-20">تمت إضافة مدرس جديد</h4>
											<div class="d-flex align-items-center justify-content-between">
												<div class="d-flex align-items-center">
													<img src="../images/avatar/1.jpg" class="avatar avatar-sm mr-10 avatar-pill">
													<p class="text-fade font-size-12 mb-0">خلدون يلداني</p>
												</div>
												<p class="text-fade font-size-12 mb-0">08 Nov 2024</p>
											</div>
										</div>
										<div class="bg-gray-100 p-15 rounded10 mb-20">
											<div>
												<span class="badge badge-sm badge-dot badge-primary mr-5"></span>
												مدرسة الجودة
											</div>
											<h4 class="my-20">تمت إضافة طالب جديد</h4>
											<div class="d-flex align-items-center justify-content-between">
												<div class="d-flex align-items-center">
													<img src="../images/avatar/2.jpg" class="avatar avatar-sm mr-10 avatar-pill">
													<p class="text-fade font-size-12 mb-0">هشام الشربيني</p>
												</div>
												<p class="text-fade font-size-12 mb-0">08 Nov 2024</p>
											</div>
										</div>
										
																		
									</div>
								</div>
								<div class="box-footer text-center p-0">
									<a href="<?php echo base_url(); ?>master/view_all_activities" class="btn btn-block btn-primary-light">عرض الكل</a>
								</div>
							</div>
						</div>
						
						<div class="col-lg-8">
							<div class="box">
								<div class="box-header">
									<h4 class="box-title">المحاضرات حسب الأيام والأوقات</h4>
								</div>
								<div class="box-body">
									
									<div id="charts_widget_2_chart"></div>
								</div>
							</div>
							<div class="row">
								<div class="col-6">
									<a class="box box-link-shadow text-center pull-up" href="javascript:void(0)">
										<div class="box-body py-25 bg-info-light px-5">
											<p class="font-weight-600 text-info">عدد المحاضرات المباشرة الآن</p>
										</div>
										<div class="box-body">
											<h1 class="countnm font-size-50 m-0">5</h1>
										</div>
									</a>
								</div>
								<div class="col-6">
									<a class="box box-link-shadow text-center pull-up" href="javascript:void(0)">
										<div class="box-body py-25 bg-info-light px-5">
											<p class="font-weight-600 text-info">عدد المحاضرات الكلي</p>
										</div>
										<div class="box-body">
											<h1 class="countnm font-size-50 m-0">250</h1>
										</div>
									</a>
								</div>
							</div>
						</div>
					
</div>
<script>

$( document ).ready(function() {
if( $('#doughnut-chart2').length > 0 ){
		var ctx7 = document.getElementById("doughnut-chart2").getContext("2d");
		var data7 = {
			 labels: [
			"عدد الطلاب الإناث",
			"عدد الطلاب الذكور"
		],
		datasets: [
			{
				data: [300, 50],
				backgroundColor: [
					"#389f99",
					"#ee1044"
				],
				hoverBackgroundColor: [
					"#18625e",
					"#b31338"
				]
			}]
		};
		
		var doughnutChart = new Chart(ctx7, {
			type: 'doughnut',
			data: data7,
			options: {
				animation: {
					duration:	3000
				},
				responsive: true,
				legend: {
					labels: {
					fontFamily: "Nunito Sans",
					fontColor:"#878787"
					}
				},
				tooltip: {
					backgroundColor:'rgba(33,33,33,1)',
					cornerRadius:0,
					footerFontFamily:"'Nunito Sans'"
				},
				elements: {
					arc: {
						borderWidth: 0
					}
				}
			}
		});
	}
	
	
	
	if( $('#doughnut-chart1').length > 0 ){
		var ctx7 = document.getElementById("doughnut-chart1").getContext("2d");
		var data7 = {
			 labels: [
			"الصف الأول",
			"الصف الثاني",
			"الصف الثالث",
			"الصف الرابع",
			"الصف الخامس",
			"الصف السادس",
			"أول متوسط",
			"ثاني متوسط",
			"ثالث متوسط",
			"أول ثانوي",
			"ثاني ثانوي",
			"ثالث ثانوي"
		],
		datasets: [
			{
				data: [300, 50, 100, 230, 430, 100, 212, 231, 98, 112, 141, 164],
				backgroundColor: [
					"#389f99",
					"#a09e6b",
					"#e11044",
					"#0da090",
					"#a00d3e",
					"#111011",
					"#056711",
					"#0a56bc",
					"#a205c9",
					"#643a6e",
					"#0c1336",
					"#09c399",
					"#c7c002"
					
				],
				hoverBackgroundColor: [
					"#18625e",
					"#b31338"
				]
			}]
		};
		
		var doughnutChart = new Chart(ctx7, {
			type: 'doughnut',
			data: data7,
			options: {
				animation: {
					duration:	3000
				},
				responsive: true,
				legend: {
					labels: {
					fontFamily: "Nunito Sans",
					fontColor:"#878787"
					}
				},
				tooltip: {
					backgroundColor:'rgba(33,33,33,1)',
					cornerRadius:0,
					footerFontFamily:"'Nunito Sans'"
				},
				elements: {
					arc: {
						borderWidth: 0
					}
				}
			}
		});
	}
	
	
	
	if( $('#doughnut-chart3').length > 0 ){
		var ctx6 = document.getElementById("doughnut-chart3").getContext("2d");
		var data6 = {
			 labels: [
			"lab 1",
			"lab 2",
			"lab 3"
		],
		datasets: [
			{
				data: [300, 50, 100],
				backgroundColor: [
					"#689f38",
					"#38649f",
					"#389f99"
				],
				hoverBackgroundColor: [
					"#33691e",
					"#244674",
					"#18625e"
				]
			}]
		};
		
		var pieChart  = new Chart(ctx6,{
			type: 'pie',
			data: data6,
			options: {
				animation: {
					duration:	3000
				},
				responsive: true,
				legend: {
					labels: {
					fontFamily: "Nunito Sans",
					fontColor:"#878787"
					}
				},
				tooltip: {
					backgroundColor:'rgba(33,33,33,1)',
					cornerRadius:0,
					footerFontFamily:"'Nunito Sans'"
				},
				elements: {
					arc: {
						borderWidth: 0
					}
				}
			}
		});
	}
	
	
	var options = {
        series: [{
            name: "Hours Spend",
            data: [3, 4, 10, 5, 1, 2]
        }],
        chart: {
			foreColor:"#bac0c7",
          height: 180,
          type: 'area',
          zoom: {
            enabled: false
          }
        },
		colors:['#0052cc'],
        dataLabels: {
          enabled: false,
        },
        stroke: {
          	show: true,
			curve: 'smooth',
			lineCap: 'butt',
			colors: undefined,
			width: 1,
			dashArray: 0, 
        },		
		markers: {
			size: 1,
			colors: '#0052cc',
			strokeColors: '#0052cc',
			strokeWidth: 2,
			strokeOpacity: 0.9,
			strokeDashArray: 0,
			fillOpacity: 1,
			discrete: [],
			shape: "circle",
			radius: 5,
			offsetX: 0,
			offsetY: 0,
			onClick: undefined,
			onDblClick: undefined,
			hover: {
			  size: undefined,
			  sizeOffset: 3
			}
		},	
        grid: {
			borderColor: '#f7f7f7', 
          row: {
            colors: ['transparent'], // takes an array which will be repeated on columns
            opacity: 0
          },			
		  yaxis: {
			lines: {
			  show: true,
			},
		  },
        },
		fill: {
			type: "gradient",
			gradient: {
			  shadeIntensity: 1,
			  opacityFrom: 0.01,
			  opacityTo: 1,
			  stops: [0, 90, 100]
			}
		  },
        xaxis: {
          categories: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
		  labels: {
			show: true,        
          },
          axisBorder: {
            show: true
          },
          axisTicks: {
            show: true
          },
          tooltip: {
            enabled: true,        
          },
        },
        yaxis: {
          labels: {
            show: true,
            formatter: function (val) {
              return val + "Hr";
            }
          }
        
        },
      };
	var chart = new ApexCharts(document.querySelector("#charts_widget_2_chart"), options);
      chart.render();
	
	
	var options = {
          series: [{
          name: 'Lesson',
          data: [44, 55, 41, 67, 22, 43, 44, 55, 41, 67, 22, 90]
        }, {
          name: 'Task',
          data: [13, 23, 20, 8, 13, 27, 13, 23, 20, 8, 13, 40]
        }],
          chart: {
		  foreColor:"#bac0c7",
          type: 'bar',
          height: 347,
          stacked: true,
          toolbar: {
            show: false
          },
          zoom: {
            enabled: true
          }
        },
        responsive: [{
          breakpoint: 480,
          options: {
            legend: {
              position: 'bottom',
              offsetX: -10,
              offsetY: 0
            }
          }
        }],		
		grid: {
			show: true,
			borderColor: '#f7f7f7',      
		},
		colors:['#6993ff', '#f64e60'],
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '20%',
		    colors: {
				backgroundBarColors: ['#f0f0f0'],
				backgroundBarOpacity: 1,
			},
          },
        },
        dataLabels: {
          enabled: false
        },
 
        xaxis: {
          categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        },
        legend: {
          show: true,
		  position: 'top',
      	  horizontalAlign: 'right',
        },
        fill: {
          opacity: 1
        }
        };

        var chart = new ApexCharts(document.querySelector("#charts_widget_1_chart"), options);
        chart.render();
	
	
	
	
	
	
});
</script>				

		
</div>				


<div class="row">
    <div class="col-lg-4 col-md-8 col-sm-12 col-xs-12">
                  <div class="x_panel">
                    
                     <div class="x_content">
                      <div class="dashboard-widget-content">
                          <table class="table table-borderd" style="width: 100%">
                              <tr>
                                  <th style="text-align: right; ">اسم المدرسة</th>
                                  <th style="text-align: center;">عدد الطلاب</th>
                              </tr>
                              <?php foreach($all_schools as $a){ ?>
                              <tr>
                                  <td>
                                      <?php echo $a->name; ?>
                                  </td>
                                  <td style="text-align: center;">
                                      <?php echo $a->nof_students; ?>
                                  </td>
                              </tr>
                              
                              <?php } ?>
                          </table>
                      </div>
                     </div>
                 </div>
    </div>





    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                  <div class="x_panel">
                    
                     <div class="x_content">
                      <div class="dashboard-widget-content">
                         <script src='https://cdn.plot.ly/plotly-2.27.0.min.js'></script>
                         <div id='myDiv'></div>                         
                         <script>
                             var data = [
                                  {
                                    x: [
                                        <?php foreach($all_courses_types as $c){ ?>
                                        '<?php echo $c->ar_name; ?>',
                                        <?php } ?>
                                        ],
                                    y: [<?php foreach($all_courses_types as $c){ ?>
                                        '<?php echo $c->nof_students; ?>',
                                        <?php } ?>],
                                    type: 'bar'
                                  }
                                ];
                                
                                Plotly.newPlot('myDiv', data);

                         </script>
                         
                         
                         
                         
                         
                      </div>
                     </div>
                 </div>
    </div>

</div>





           

          
 
 
 <?php $this->load->view('template/footer'); ?>